import requests
import csv
import re

# URL of the plain-text URL list
url = "https://urlhaus.abuse.ch/downloads/text_online/"

# Fetch the plain-text URL list
response = requests.get(url)
response.raise_for_status()  # Check that the request was successful

# Extract URLs from the response text
lines = response.text.splitlines()
urls = [line for line in lines if line.startswith("http")]

# Regular expression to match IP addresses
ip_pattern = re.compile(r'http://\d+\.\d+\.\d+\.\d+')

# Filter out URLs that contain IP addresses
filtered_urls = [url for url in urls if not ip_pattern.match(url)]

# Write the filtered URLs to a CSV file
csv_file = "malware_urls.csv"
with open(csv_file, mode="w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["url"])  # Write header
    for url in filtered_urls:
        writer.writerow([url])

print(f"Filtered URLs have been written to {csv_file}")